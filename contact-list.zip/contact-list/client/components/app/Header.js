import React, {Component} from 'react';
import {} from './style.less';

class Header extends Component {
  render() {
    return <header id="header">Welcome to Contact List with React, Express, Node and Cassandra!</header>;
  }
}

export default Header;