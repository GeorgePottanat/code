import React, {Component} from 'react';
import {} from './style.less';

class Footer extends Component {
  render() {
    return <footer className="navbar navbar-fixed-bottom">Developed by George Pottanat </footer>;
  }
}

export default Footer;