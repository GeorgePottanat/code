import React, {Component} from 'react';

class LoadContacts extends Component {
  render() {
    return(
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>

    );
  }
}

export default LoadContacts;